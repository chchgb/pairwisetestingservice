package pairwisetesting.dependency.test;

public class C {
	D d;
	B b;
}
