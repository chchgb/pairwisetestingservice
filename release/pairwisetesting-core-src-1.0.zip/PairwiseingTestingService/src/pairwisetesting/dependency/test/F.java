package pairwisetesting.dependency.test;

public class F {
	public F(IX x) {

	}

	G g;
	E e;
}
