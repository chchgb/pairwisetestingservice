package pairwisetesting.dependency.test;

public class G {
	A a;
	F f;
}
