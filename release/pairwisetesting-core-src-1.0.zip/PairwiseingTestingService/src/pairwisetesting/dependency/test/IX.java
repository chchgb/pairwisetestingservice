package pairwisetesting.dependency.test;

public interface IX {

}
