package pairwisetesting.dependency.test;

public interface IZ {

}
