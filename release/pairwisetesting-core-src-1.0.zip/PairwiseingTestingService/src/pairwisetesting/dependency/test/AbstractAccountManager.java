package pairwisetesting.dependency.test;

public abstract class AbstractAccountManager {

}
