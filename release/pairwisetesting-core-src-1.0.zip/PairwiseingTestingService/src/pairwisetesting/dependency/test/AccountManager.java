package pairwisetesting.dependency.test;

public class AccountManager implements IAccountManager {

	public void store(String name) {
		
	}

}
