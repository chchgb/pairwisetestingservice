package pairwisetesting.dependency.test;

public class D {
	public D(IZ z) {

	}

	E e;
	C c;
}
