package pairwisetesting.dependency.test;

public class E {
	public E(IY y) {

	}

	F f;
	D d;
}
