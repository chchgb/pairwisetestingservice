package pairwisetesting.dependency.test;

public class A {
	B b;
	G g;
}
