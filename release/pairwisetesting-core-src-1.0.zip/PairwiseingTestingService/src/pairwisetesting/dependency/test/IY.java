package pairwisetesting.dependency.test;

public interface IY {

}
