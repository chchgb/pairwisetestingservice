package pairwisetesting.dependency.test;

public interface IAccountManager {
	public void store(String name);
}
