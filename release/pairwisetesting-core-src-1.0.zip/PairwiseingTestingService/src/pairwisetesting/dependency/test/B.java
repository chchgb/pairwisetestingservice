package pairwisetesting.dependency.test;

public class B {
	C c;
	A a;
}
