package pairwisetesting.coredomain;


public interface IMetaParameterProvider {

	MetaParameter get() throws MetaParameterException;

}
