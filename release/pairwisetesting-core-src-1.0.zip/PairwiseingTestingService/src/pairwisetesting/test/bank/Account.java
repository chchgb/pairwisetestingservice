package pairwisetesting.test.bank;

public class Account {

}
