package pairwisetesting.test.bank;

public class AccountManager implements IAccountManager {

	public void beginTransaction() {

	}

	public void commit() {

	}

	public double withdraw(String accountId, double amount)  {
		return 0;
	}

}
