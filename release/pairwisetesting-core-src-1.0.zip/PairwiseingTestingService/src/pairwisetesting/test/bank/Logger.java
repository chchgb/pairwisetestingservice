package pairwisetesting.test.bank;

public interface Logger {
	public void log(Object msg);
}
