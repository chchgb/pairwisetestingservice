package pairwisetesting.test.bookstore;

public interface Logger {
	public void log(Object msg);
}
