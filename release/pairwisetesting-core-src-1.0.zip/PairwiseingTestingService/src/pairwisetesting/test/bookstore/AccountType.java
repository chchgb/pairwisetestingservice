package pairwisetesting.test.bookstore;
public enum AccountType {
	STUDENT, INTERNAL, NORMAL
}